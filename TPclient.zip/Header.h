#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <list>
#include <map>
#include <vector>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <mutex>
#include <thread>
#include <atomic>
#include <unistd.h>
#include <cstdio>
#include <sstream>
#include <bitset>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <math.h>
#include <arpa/inet.h>
#include <iconv.h>




using namespace std;
using namespace std::chrono;

typedef unsigned char Byte;
typedef list<string> strList;
typedef vector<string> strVector;
typedef chrono::time_point<chrono::system_clock> Time;


#define TOF			100
#define TDOA		101
#define RF_STATUS_REG	2
#define RF_STATUS_UNREG	1

#define ERROR				-1
#define READ				0
#define WRITE				1
#define DELETE				2
#define WRITE_LAST			3
#define SELECT				4
#define SET_NODEID			5
#define READ_NEXT			6
#define ADD_ANCH			8
#define UPD_ANCH			9
#define DEL_ANCH			10
#define GET_ANCH			11
#define FIND_SECT			12
#define READ_THIS			14
#define ADD 				16
#define SIZE 				17

// ������ 0 "Ok"
// ������ 1 "����������" - ���� �������� ����� '0' 
// ������ 2 "������������ ������ �����" - ���� �� ���� ����� ������� ����� '0' 
// ������ 3 "�������������� ������ �����" - ���� ������� ����� ERROR_LEVEL%
#define ST_NODE_OK			0
#define ST_NODE_FAIL		1
#define ST_NODE_RE_HIGH		2
#define ST_NODE_RE_LOW		3
#define ST_NODE_NOT_MAC		4
#define ST_NODE_DISCONNECT	5


#define CONS_ONLY	1
#define FILE_ONLY	2
#define CONS_FILE	3
#define NO_TARGET	0
#define CO			1
#define FO			2
#define CF			3
#define NO			0

#define PI	3.16159265358979323846
#define PACK_LENGTH		512
#define DIST_CORR		50 // ��� ��������� ���������� �� ����
#define ERROR_LEVEL		50.0 // ���������� ���������� ������� ������������� TDOA , � ���������

// ���� ���������
#define GET				0x54
#define SET				0x55
#define G_RESP			0x56
#define S_RESP			0x57
#define ERR				0x60
#define NOTI			0x61

//��������� �� nT
#define RRN				0x62
#define SBIV			0x31
#define SDAT			0x21
#define SSET			0x01
#define SSTART			0x23
#define SSTOP			0x25
#define TEST_R			0x72
#define PRESURE			0x75
#define SPIN			0x5B

//������� � �������
#define GET_LOCATION	0xA1

#define parLOC_X		1
#define parLOC_Y		2
#define parLOC_Z		3
#define parACC_X		5
#define parACC_Y		6
#define parACC_Z		7
#define parREGISTRATION	9
#define parBATTERY		10
#define parTEMPERATURE	4
#define parLOCATION		25
#define parONLINE		11
#define parNODE_STATUS	12
#define parBUTTON		14
#define parREST			75
#define parDOWN			74
#define parBATTERY_LOW	71
#define parTEMP_LOW		72
#define parTEMP_HIGH	73

// ������� ��������
#define BOOL(x) (!(!(x)))
#define BitSet(arg,posn) (arg = (arg) | (1L << (posn)))
#define BitClr(arg,posn) ((arg) & ~(1L << (posn)))
#define BitTst(arg,posn) BOOL((arg) & (1L << (posn)))
#define BitFlp(arg,posn) ((arg) ^ (1L << (posn)))

 

// ��������� ///

struct stDeviationParam
{
	unsigned  devX;
	unsigned  devY;
	unsigned  devZ;
	unsigned  devR;
	unsigned  devP1; // battery
	unsigned  devP2; // temperature
	unsigned  devP3; // acc x
	unsigned  devP4; // acc y
	unsigned  devP5; // acc z
	unsigned  devP6; // on/off line
	unsigned  devP7; // button
	unsigned  devP8; // RSSI
	unsigned  devP9;
	unsigned  devP10;

	stDeviationParam() {
		devX = 100;
		devY = 100;
		devZ = 100;
		devR = 100;
		devP1 = 0; // battery
		devP2 = 0; // temperature
		devP3 = 0; // acc x
		devP4 = 0; // acc y
		devP5 = 0; // acc z
		devP6 = 0; // on/off line
		devP7 = 0; // button
		devP8 = 0; // RSSI
		devP9 = 0;
		devP10 = 0;
	}
};
//----------------------------------------------------------------

#define REAL_COORD -10000000.00
// ��������� ��� �������� ���������
struct triD
{
	double X;
	double Y;
	double Z;
	double R;
	triD() {
		X = 0;
		Y = 0;
		Z = 0;
		R = 0;
	}
	void Copy(triD* st)
	{
		st->X = X;
		st->Y = Y;
		st->Z = Z;
		st->R = R;
	}
	void Clear()
	{
		X = 0;
		Y = 0;
		Z = 0;
		R = 0;
	}
};
//----------------------------------------------------------------

// ��������� ���������� ����
struct stParams
{
	uint8_t param_1; // batary
	int16_t param_2; // temperature
	int param_3; // acselerometr_X
	int param_4; // acselerometr_Y
	int param_5; // acselerometr_Z
	int8_t param_6; // ON/OF line
	int param_7; // button
	int8_t param_8; // RSSI
	uint8_t param_9;	//������� �����������
	uint8_t param_10; // device class
	int8_t param_11; // rest_status
	int8_t param_12; // down_status
	uint8_t param_13; // batary low
	int8_t param_14; // temp low
	int8_t param_15; // temp hi
	float param_16;	/* �������� */
	float param_17;	/* ����������� */
	float param_18;	/* ��������� */
	uint64_t param_19;	/* RFID */
	bool param_20;	/*����� �� �������*/
	
	stParams() {
		param_1 = 0;
		param_2 = 0;
		param_3 = 0;
		param_4 = 0;
		param_5 = 0;
		param_6 = 0;
		param_7 = 1;
		param_8 = 0;
		param_9 = 0;
		param_10 = 0;
		param_11 = 0;
		param_12 = 0;
		param_13 = 0;
		param_14 = 0;
		param_15 = 0;
		param_16 = 0;
		param_17 = 0;
		param_18 = 0;
		param_19 = ERROR;
		param_20 = false;
	}
	void Copy(stParams* st)
	{
		st->param_1 = param_1;
		st->param_2 = param_2;
		st->param_3 = param_3;
		st->param_4 = param_4;
		st->param_5 = param_5;
		st->param_6 = param_6;
		st->param_7 = param_7;
		st->param_8 = param_8;
		st->param_9 = param_9;
		st->param_10 = param_10;
		st->param_11 = param_11;
		st->param_12 = param_12;
		st->param_13 = param_13;
		st->param_14 = param_14;
		st->param_15 = param_15;
		st->param_16 = param_16;
		st->param_17 = param_17;
		st->param_18 = param_18;
		st->param_19 = param_19;
		st->param_20 = param_20;
	}
	void Save(stParams* st)
	{
		st->param_1 = param_1;
		st->param_2 = param_2;
		st->param_3 = param_3;
		st->param_4 = param_4;
		st->param_5 = param_5;
		st->param_6 = param_6;
		st->param_7 = st->param_7 && param_7; // && ��� ���� ����� ��������� ������� ������ '0'
		st->param_8 = param_8;
		st->param_9 = param_9;
		st->param_10 = param_10;
		st->param_11 = param_11;
		st->param_12 = param_12;
		st->param_13 = param_13;
		st->param_14 = param_14;
		st->param_15 = param_15;
		st->param_15 = param_15;
		st->param_16 = param_16;
		st->param_17 = param_17;
		st->param_18 = param_18;
		st->param_19 = param_19;
		st->param_20 = param_20;
	}
	void Clear()
	{
		param_1 = 0;
		param_2 = 0;
		param_3 = 0;
		param_4 = 0;
		param_5 = 0;
		param_6 = 0;
		param_7 = 1; // �������� ��������� ������ '1'
		param_8 = 0;
		param_9 = 0;
		param_10 = 0;
		param_11 = 0;
		param_12 = 0;
		param_13 = 0;
		param_14 = 0;
		param_15 = 0;
		param_16 = 0;
		param_17 = 0;
		param_18 = 0;
		param_19 = ERROR;
		param_20 = false;
	}
};
//-------------------------------------------------------------------------

// ��������� ���������: ��������� � ���������
struct stStatus
{
	Time dt;
	triD location;
	string section;
	stParams params;
	
	stStatus() {
		section = "";
	}

	void CopyTo(stStatus* st)
	{
		st->dt = dt;
		st->section = section;
		params.Copy(&(st->params));
		st->location.X = location.X;
		st->location.Y = location.Y;
		st->location.Z = location.Z;
		st->location.R = location.R;
	}
	void Clear()
	{
		section = "";
		location.Clear();
		params.Clear();
	}
};
//------------------------------------------------------------------------

// ��������� ������
struct stAnchor
{
	int64_t id;
	int channel;
	triD location;
	bool SP;
	string ip_addr;
	int status;
	int RSSI;
	short int technology;
	
	stAnchor() {
		ip_addr = "";
		status = ERROR;
		RSSI = ERROR;
		technology = TDOA;
	}
	void Copy(stAnchor* an)
	{
		an->id = id;
		an->channel = channel;
		an->SP = SP;
		an->ip_addr = ip_addr;
		an->status = status;
		an->technology = technology;
		location.Copy(&an->location);
	}
	void Clear() 
	{
		id = -1;
		channel = 0;
		location.Clear();
		SP = true;
		ip_addr = "";
		status = ERROR;
		RSSI = ERROR;
		technology = TDOA;
	}
};

// ��������� ������
struct stSection
{
	string id;
	int dimension;
	bool rssi_check;
	int rssi_cap;
	int rssi_loss;
	bool coord_check;
	string coord_name;
	double coord_cap_min;
	double coord_cap_max;
	double coord_loss_min;
	double coord_loss_max;
	triD location;
	vector <stAnchor> anchors;
	int rssi_max;
	int rssi_min;
	short int technology;
	bool height_determination;

	stSection() {
		id = "";
		dimension = 2;
		rssi_check = false;
		rssi_cap = -60;
		rssi_loss = -70;
		coord_check = false;
		coord_name = "";
		coord_cap_min = 0.0;
		coord_cap_max = 0.0;
		coord_loss_min = 0.0;
		coord_loss_max = 0.0;
		location.X = REAL_COORD;
		location.Y = REAL_COORD;
		location.Z = REAL_COORD;
		rssi_max = 0;
		rssi_min = -100;
		technology = TDOA;
		height_determination = false;
	}
	void Clear()
	{
		id = "";
		dimension = 2;
		rssi_check = false;
		rssi_cap = -60;
		rssi_loss = -70;
		location.X = REAL_COORD;
		location.Y = REAL_COORD;
		location.Z = REAL_COORD;
		anchors.clear();
		rssi_max = 0;
		rssi_min = -100;
		height_determination = false;
	}
	void CopyTo(stSection* sect)
	{
		sect->id = id;
		sect->dimension = dimension;
		sect->rssi_check = rssi_check;
		sect->rssi_cap = rssi_cap;
		sect->rssi_loss = rssi_loss;
		sect->coord_check = coord_check;
		sect->coord_name = coord_name;
		sect->coord_cap_min = coord_cap_min;
		sect->coord_cap_max = coord_cap_max;
		sect->coord_loss_min = coord_loss_min;
		sect->coord_loss_max = coord_loss_max;
		location.Copy(&sect->location);
		sect->technology = technology;
		sect->height_determination = height_determination;
		
		stAnchor an_temp;
		for (size_t i = 0; i < anchors.size(); i++) {
			anchors[i].Copy(&an_temp);
			sect->anchors.push_back(an_temp);
			an_temp.Clear();
		}
	}
};

//-------------------------------------------------------------------------

// ��������� ���. � ����� TOF
struct stStatus_TOF
{
	Time dt;
	stParams params;
	map<uint64_t, stStatus> nodes;
	void Clear()
	{
		nodes.clear();
	}
};
//----------------------------------------------------------------------------

// ������� ��������� ��������� �����
struct stTagStatus
{
	Time dt;
	Time dt_loc_upd;
	Time dt_rest;
	triD T;
	stParams params;
	string section;
	stAnchor an_best;
	short int technology;
	bool button;
	stTagStatus() {
		dt = system_clock::now();
		dt_loc_upd = dt;
		dt_rest = dt;
		
		button = false;
		section = "";
		technology = TDOA;
	}
	void CopyTo(stTagStatus* tag_status) {
		tag_status->dt = dt;
		tag_status->dt_loc_upd = dt_loc_upd;
		tag_status->dt_rest = dt_rest;
		
		tag_status->button = button;
		T.Copy(&tag_status->T);
		params.Copy(&tag_status->params);
		tag_status->section = section;
		an_best.Copy(&tag_status->an_best);
		tag_status->technology = technology;
	}
};
//------------------------------------------

// ��������� ������� ��� device class
struct stDC_property
{
	int speed_max;
	int move_rest;
	int move_down;
	int time_rest;
	int battery_low;
	int temp_low;
	int temp_high;

	stDC_property() {
		speed_max = 3;
		move_rest = 5;
		move_down = 500;
		time_rest = 60;
		battery_low = 38;
		temp_low = 10;
		temp_high = 50;
	}
	void CopyTo(stDC_property* dc_property) {
		dc_property->speed_max = speed_max;
		dc_property->move_rest = move_rest;
		dc_property->move_down = move_down;
		dc_property->time_rest = time_rest;
		dc_property->battery_low = battery_low;
		dc_property->temp_low = temp_low;
		dc_property->temp_high = temp_high;
	}
};

//---------------------------------------------
// ��������� ��������� ���� � ������ ������� TDOA
struct stSectLocation
{
	string id;
	triD location;
};
//--------------------------------------------------
/// ��������� ������������ ����������� TOF � TDOA
struct stSubQuery {
	string subq_dt; // ��������� ��������� ��� �������
	string subq_tag; // �������� ��������� ��� �����
	string subq_param_id;
	string subq_param_val;
	string subq_rfid;
	string subq_reg;
	stSubQuery(){
		subq_dt = "";
		subq_tag = "";
		subq_param_id = "";
		subq_param_val = "";
		subq_rfid = "";
		subq_reg = "";
	}
	void Clear() {
		subq_dt.clear();
		subq_tag.clear();
		subq_param_id.clear();
		subq_param_val.clear();
		subq_rfid.clear();
		subq_reg.clear();
	}
};

struct stMsgRTLS
{
	uint64_t tag;
	Time dt;
	Time dt_loc_upd;
	triD T;
	triD Ta;
	stParams params;
	string section;
	unsigned short node_count;
	short int technology;
	vector< stSectLocation > v_sects;
	vector< stAnchor > v_ans;

	stMsgRTLS() {
		tag = ERROR;
		dt = system_clock::now();
		dt_loc_upd = dt;
		section = "";
		node_count = 0;
		technology = TDOA;
	}
	void CopyTo(stMsgRTLS* rtls) {
		rtls->tag = tag;
		rtls->dt = dt;
		rtls->dt_loc_upd = dt_loc_upd;
		T.Copy(&rtls->T);
		Ta.Copy(&rtls->Ta);
		rtls->section = section;
		rtls->node_count = node_count;
		rtls->technology = technology;
	}
	void Clear() {
		tag = ERROR;
		dt = system_clock::now();
		dt_loc_upd = dt;
		section = "";
		node_count = 0;
		T.Clear();
		Ta.Clear();
		params.Clear();
		v_sects.clear();
		v_ans.clear();
		technology = TDOA;
	}
};
//------------------------------------------



long long int kv(long arg);
double kv(double arg);

void reverse(char s[]);
string itoa(long long int n);
string itoa_hex(int64_t n, bool alignment = true);
bool atob(string str);
string btoa(bool value);
int buffToShort(unsigned char* buffer);
void intToBytes(long long int paramInt, unsigned char* buf, size_t size);
void intToBytes_rev(long long int paramInt, unsigned char* buf, size_t size);
string ByteToMac(Byte* pByte, size_t nSize);

uint64_t buff_5_ToInt64(uint8_t* buffer, bool order);
int64_t buff_5_ToInt64(int8_t* buffer, bool order = false);
uint64_t buff_6_ToInt64(uint8_t* buffer, bool order = false);
int64_t buff_6_ToInt64(int8_t* buffer, bool order = false);
uint64_t buffToInt64(uint8_t* buffer, bool order = false);
uint32_t buffToInt32(uint8_t* buffer, bool order = false);
int32_t buffToInt32(int8_t* buffer, bool order = false);
uint16_t buffToInt16(uint8_t* buffer, bool order = false);
int16_t buffToInt16(int8_t* buffer, bool order = false);
string DigToStr(int8_t digit, bool format = true);

void ssleep(size_t sec); // ��� � ��������
void msleep(size_t msec); // ��� � ������������
uint64_t get_time_ms(Time);
uint64_t get_time_s(Time);
uint64_t get_time_ms();
uint64_t get_time_s();
string GetTime();
string GetTime_ms(bool add_ms=false);
bool wait4(atomic<bool>* flag, uint64_t msec);



