#include "Loger.h"

Loger Log;

char en[] = { '\n' };

/* reverse:  �������������� ������ s �� ����� */
void Loger::reverse(char s[])
{
	int i, j;
	char c;

	for (i = 0, j = strlen(s) - 1; i < j; i++, j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}
string Loger::itoa(long long int n)
{
	string result;
	long long int sign;

	if ((sign = n) < 0)  /* ���������� ���� */
		n = -n;          /* ������ n ������������� ������ */
	do {       /* ���������� ����� � �������� ������� */
		result = result + (char)(n % 10 + '0');   /* ����� ��������� ����� */
	} while ((n /= 10) > 0);     /* ������� */
	if (sign < 0)
		result.append("-");
	reverse((char*)result.c_str());
	return result;
}
/***************************************************************/

void* thread_Loger(void* arg)
{
	Loger* Log = (Loger*)arg;
	cout << "Loger thread started" << endl;
	while (Log->Terminated == false) {
		while (Log->List(READ))
			this_thread::yield();
#ifdef _WIN32
		Sleep(100);
#else
		usleep(100000);
#endif
	}
	Log->Terminated = false;
	cout << "Loger thread stoped" << endl;
	return nullptr;
}
//-----------------------------------------------------------------
Loger::Loger()
{
	target = CONS_ONLY;
	nameFileToLog = "This_log.txt";
	Terminated = false;

	try
	{
		thrLoger = thread(thread_Loger, (void*)this);
		thrLoger.detach();
	}
	catch (const std::exception&)
	{
		cout << "Loger threads fail" << endl;
		return;
	}
}
//-----------------------------------------------------------------------------

void Loger::ToLog(string valueMSG, int terget, const char* valueBuf, size_t BufLength)
{
	log_msg* msg = new log_msg(BufLength);
	msg->target = target;
	msg->msg = GetTime() + "  " + valueMSG;
	if (valueBuf != nullptr && BufLength != 0) {
		msg->buf_length = BufLength;
		for (size_t i = 0; i < BufLength; i++)
			msg->buf[i] = valueBuf[i];
	}
	else
		msg->msg += en;
	List(WRITE, msg);
}
//---------------------------------------------------------------------

string Loger::GetTime()
{
	time_t t = time(NULL);
	struct tm* ti(localtime(&t));

	string mon = itoa(ti->tm_mon + 1);
	if (ti->tm_mon + 1 < 10)
		mon = "0" + itoa(ti->tm_mon + 1);
	string day = itoa(ti->tm_mday);
	if (ti->tm_mday < 10)
		day = "0" + itoa(ti->tm_mday);
	string hour = itoa(ti->tm_hour);
	if (ti->tm_hour < 10)
		hour = "0" + itoa(ti->tm_hour);
	string min = itoa(ti->tm_min);
	if (ti->tm_min < 10)
		min = "0" + itoa(ti->tm_min);
	string sec = itoa(ti->tm_sec);
	if (ti->tm_sec < 10)
		sec = "0" + itoa(ti->tm_sec);

	string str = itoa(ti->tm_year + 1900) + "-"
		+ mon + "-"
		+ day + " "
		+ hour + ":"
		+ min + ":"
		+ sec;
	return str;
}
//-------------------------------------------------------------------

void Loger::WriteToFileLog(log_msg* msg)
{
	bool retVal = true;

	FILE* pFile;
	pFile = fopen(nameFileToLog.c_str(), "a");
	if (pFile == nullptr
		|| pFile == 0)
		retVal = false;
	else
	{
		try
		{
			fprintf(pFile, msg->msg.c_str());
			if (msg->buf_length != 0) {
				for (int i = 0; i < msg->buf_length; i++)
					fprintf(pFile, " x%x", msg->buf[i]);
				fprintf(pFile, en);
			}
			fclose(pFile);
		}
		catch (...)
		{
			retVal = false;
		}
	}
}
//------------------------------------------------------------

bool Loger::List(int rw, log_msg* add_msg)
{
	try
	{
		unique_lock<mutex> lck(mtxLogFile);
		if (rw == WRITE && add_msg != nullptr) {
			if (add_msg->target != NO_TARGET) {
				log_list.push_back(add_msg);
				return true;
			}
		}
		else if (rw == READ && log_list.size() > 0) {
			log_msg* msg = log_list.front();
			switch (msg->target)
			{
			case CONS_ONLY:
				printf(msg->msg.c_str());
				if (msg->buf_length != 0) {
					for (int i = 0; i < msg->buf_length; i++)
						printf(" x%x", msg->buf[i]);
					cout << endl;
				}
				break;
			case FILE_ONLY:
				WriteToFileLog(msg);
				break;
			case CONS_FILE:
				printf(msg->msg.c_str());
				if (msg->buf != nullptr) {
					for (int i = 0; i < msg->buf_length; i++)
						printf(" x%x", msg->buf[i]);
					cout << endl;
				}
				WriteToFileLog(msg);
				break;
			case NO_TARGET:
				break;
			}
			log_list.pop_front();
			if (msg != nullptr)
				delete msg;

			return true;
		}
		return false;
	}
	catch (const std::exception&)
	{
		return false;
	}
}
