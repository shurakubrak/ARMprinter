#pragma once

#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <synchapi.h>
#else
#include <unistd.h>
#endif

#include <iostream>
#include <stdio.h>
#include <list>
#include <string.h>
#include <time.h>
#include <mutex>
#include <thread>

using namespace std;
using namespace std::chrono;

#define READ		0
#define WRITE		1

#define CONS_ONLY	1
#define FILE_ONLY	2
#define CONS_FILE	3
#define NO_TARGET	0
#define CO			1
#define FO			2
#define CF			3
#define NO			0

#define BUF_HEX_SIZE 1024 

class log_msg
{
public:
	int target;
	string msg;
	char* buf;
	size_t buf_length;

	log_msg() {
		target = 0;
		msg = "";
		buf_length = 0;
		buf = nullptr;
	}
	log_msg(size_t buf_size) {
		target = 0;
		msg = "";
		buf_length = buf_size;
		buf = new char[buf_size];
	}

	~log_msg() {
		if (buf != nullptr)
			delete buf;
	}

	void Copy(log_msg* c_msg) {
		c_msg->target = target;
		c_msg->msg = msg;
		for (size_t i = 0; i < buf_length; i++)
			c_msg->buf[i] = buf[i];
		c_msg->buf_length = buf_length;
	}
};
/********************************************/
class Loger
{
public:
	bool Terminated;
private:
	int target;
	thread thrLoger;
	list <log_msg*> log_list;

public:
	Loger();
	void ToLog(string valueMSG, int terget = CONS_ONLY, const char* valueBuf = nullptr, size_t BufLength = 0);
	bool List(int rw, log_msg* add_msg = nullptr);

private:
	string GetTime();
	void WriteToFileLog(log_msg* msg);
	mutex mtxLogFile;
	string nameFileToLog = "LogSoundCross.txt";
	void reverse(char s[]);
	string itoa(long long int n);
};

