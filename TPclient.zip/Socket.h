#pragma once
#include "Header.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

#define LenTCPbuffer		1000
#define TCP_PORT			3425
#define SERVER_CONN_NUM		1
#define SC_TM_CNTL			60000
#define SOCK_BUF_EMPTY		11/*������ ������ ����� � ������ ��� ������*/



void* thread_ClientSock_read(void* arg);

//////////////////////////////////////////////////////////////////////////////

class SocketClient
{
public:
	int ClientSock;
	sockaddr_in to_sin;
	string server_addr;
	uint16_t port;
	bool Terminated;
	bool sync;
	
protected:
	pthread_t thrRead;
	vector<Byte> message;
	bool begin;
	size_t byte_count;
	uint16_t message_length;
	bool status;
	mutex mtxIn;
	list<vector<Byte>> lstIn;

public:
	SocketClient()
	{
		ClientSock = -1;
		server_addr = "172.16.1.212";
		port = TCP_PORT;
		begin = false;
		byte_count = 0;
		message_length = 0;
		status = false;
		Terminated = false;
		sync = false;
	}

	virtual void Analys(Byte bt) { return; };

	bool	Connect(); //�������� server ������
	void	StartExchange();
	void	Close();
	bool	Status();
	bool 	Send(const char* Message, size_t size);
	bool	Recive();
	void	AddMsg(vector<Byte>* msg);
	bool	GetMsg(vector<Byte>* msg);
	bool	MsgInAccess(vector<Byte>* msg, int access);
};
//-------------------------------------------------------------------------

