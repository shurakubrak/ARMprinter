#include "Header.h"
#include "Loger.h"

extern Loger Log;
extern atomic<float> Pressure;
extern atomic<float> Temperature;
extern atomic<float> Humidity;
/////////// GLOBAL FUNCTIONS ///////////////////////////
////////////////////////////////////////////////
//    itoa
/* reverse:  �������������� ������ s �� ����� */
void reverse(char s[])
{
	int i, j;
	char c;

	for (i = 0, j = strlen(s) - 1; i < j; i++, j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}
string itoa(long long int n)
{
	string result;
	long long int sign;

	if ((sign = n) < 0)  /* ���������� ���� */
		n = -n;          /* ������ n ������������� ������ */
	do {       /* ���������� ����� � �������� ������� */
		result = result + (char)(n % 10 + '0');   /* ����� ��������� ����� */
	} while ((n /= 10) > 0);     /* ������� */
	if (sign < 0)
		result.append("-");
	reverse((char*)result.c_str());
	return result;
}
//-------------------------------------------------------------------------

string itoa_hex(int64_t n, bool alignment)
{
	if(n==0)
		return "               0";

	string s = "";
	ostringstream oss;
	oss << setfill('0');

	oss << setw(16) << hex << static_cast<uint64_t>(n) << ":";
	
	s.assign(oss.str());
	s = s.substr(0, s.length() - 1);

	/*���������� '0'*/
	if (alignment) /*������� �� ������ ��� ������������*/
		for (size_t i = 0; i < s.length(); i++) {
			if (s[i] == '0')
				s[i] = ' ';
			else
				break;
		}
	else
		while (s[0] == '0')/*������*/
			s.erase(0, 1);

	return s;
}
//--------------------------------------------------------------------------------

long long int kv(long arg) {
	return (long long int) arg * arg;
}
double kv(double arg) {
	return arg * arg;
}
//--------------------------------------------------------------------

int buffToShort(unsigned char* buffer)
{
	unsigned short a = static_cast<short>(static_cast<unsigned char>(buffer[0]) << 8 |
		static_cast<unsigned char>(buffer[1]));
	return a;
}
//----------------------------------------------------------------------------------

string ByteToMac(Byte* pByte, size_t nSize)
{
	string s = "";
	ostringstream oss;
	oss << setfill('0');

	for (int i = nSize - 1; i >= 0; i--)
	{
		oss << setw(2) << hex << static_cast<int>(pByte[i]) << ":";
	}

	s.assign(oss.str());
	s = s.substr(0, s.length() - 1);
	return s;
}
//------------------------------------------------------------

void ssleep(size_t sec)
{
	usleep(sec * 1000000);
}
void msleep(size_t msec)
{
	usleep(msec * 1000);
}
uint64_t get_time_ms(Time dt)
{
	try
	{
		return duration_cast<milliseconds>(dt.time_since_epoch()).count();
	}
	catch (const std::exception&)
	{
		return 0;
	}
}
uint64_t get_time_s(Time dt)
{
	try
	{
		return duration_cast<seconds>(dt.time_since_epoch()).count();
	}
	catch (const std::exception&)
	{
		return 0;
	}
}
uint64_t get_time_ms()
{
	try
	{
		return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	}
	catch (const std::exception&)
	{
		return 0;
	}
}
uint64_t get_time_s()
{
	try
	{
		return duration_cast<seconds>(system_clock::now().time_since_epoch()).count();
	}
	catch (const std::exception&)
	{
		return 0;
	}
}
string GetTime()
{
	time_t t = time(NULL);
	struct tm* ti(localtime(&t));

	string mon = itoa(ti->tm_mon + 1);
	if (ti->tm_mon + 1 < 10)
		mon = "0" + itoa(ti->tm_mon + 1);
	string day = itoa(ti->tm_mday);
	if (ti->tm_mday < 10)
		day = "0" + itoa(ti->tm_mday);
	string hour = itoa(ti->tm_hour);
	if (ti->tm_hour < 10)
		hour = "0" + itoa(ti->tm_hour);
	string min = itoa(ti->tm_min);
	if (ti->tm_min < 10)
		min = "0" + itoa(ti->tm_min);
	string sec = itoa(ti->tm_sec);
	if (ti->tm_sec < 10)
		sec = "0" + itoa(ti->tm_sec);

	string str = itoa(ti->tm_year + 1900) + "-"
		+ mon + "-"
		+ day + " "
		+ hour + ":"
		+ min + ":"
		+ sec;
	return str;
}
string GetTime_ms(bool add_ms)
{
	Time t = system_clock::now();
	time_t dt = system_clock::to_time_t(t);
	uint64_t mm = get_time_ms(t);
	string ms;
	if (add_ms)
		ms = itoa(mm - (dt * 1000));
	else
		ms = itoa(mm - (dt * 1000) + 1);

	struct tm* ti(localtime(&dt));
	string ret = itoa(ti->tm_year + 1900) + "-"
		+ itoa(ti->tm_mon + 1) + "-"
		+ itoa(ti->tm_mday) + " "
		+ itoa(ti->tm_hour) + ":"
		+ itoa(ti->tm_min) + ":"
		+ itoa(ti->tm_sec) + "."
		+ ms;

	return ret;
}
//------------------------------------------------------

bool wait4(atomic<bool>* flag, uint64_t msec)
{
	try
	{
		uint64_t start = get_time_ms();
		bool fl_start = *flag;
		while ((get_time_ms() - start) < msec)
			if (*flag != fl_start)
				return true;
			else
				msleep(5);
		return false;
	}
	catch (const std::exception&)
	{

	}
}
//-------------------------------------------------------------------------

//--------------------------------------------------------

uint64_t buffToInt64(uint8_t* buffer, bool order)
{
	uint64_t a;
	if (!order)
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[0]) << 56 |
			static_cast<unsigned long>(buffer[1]) << 48 |
			static_cast<unsigned long>(buffer[2]) << 40 |
			static_cast<unsigned long>(buffer[3]) << 32 |
			static_cast<unsigned long>(buffer[4]) << 24 |
			static_cast<unsigned long>(buffer[5]) << 16 |
			static_cast<unsigned long>(buffer[6]) << 8 |
			static_cast<unsigned long>(buffer[7]));
	else
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[7]) << 56 |
			static_cast<unsigned long>(buffer[6]) << 48 |
			static_cast<unsigned long>(buffer[5]) << 40 |
			static_cast<unsigned long>(buffer[4]) << 32 |
			static_cast<unsigned long>(buffer[3]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[1]) << 8 |
			static_cast<unsigned long>(buffer[0]));

	return a;
}
//--------------------------------------------------------------------------------------

uint64_t buff_5_ToInt64(uint8_t* buffer, bool order)
{
	uint64_t a;
	if (!order)
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[0]) << 32 |
			static_cast<unsigned long>(buffer[1]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[3]) << 8 |
			static_cast<unsigned long>(buffer[4]));
	else
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[4]) << 32 |
			static_cast<unsigned long>(buffer[3]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[1]) << 8 |
			static_cast<unsigned long>(buffer[0]));

	return a;
}
int64_t buff_5_ToInt64(int8_t* buffer, bool order)
{
	int64_t a;
	if (!order)
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[0]) << 32 |
			static_cast<unsigned long>(buffer[1]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[3]) << 8 |
			static_cast<unsigned long>(buffer[4]));
	else
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[4]) << 32 |
			static_cast<unsigned long>(buffer[3]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[1]) << 8 |
			static_cast<unsigned long>(buffer[0]));

	return a;
}
//--------------------------------------------------------------------------------------

uint64_t buff_6_ToInt64(uint8_t* buffer, bool order)/**/
{
	uint64_t a;
	if (!order)
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[0]) << 40 |
			static_cast<unsigned long>(buffer[1]) << 32 |
			static_cast<unsigned long>(buffer[2]) << 24 |
			static_cast<unsigned long>(buffer[3]) << 16 |
			static_cast<unsigned long>(buffer[4]) << 8 |
			static_cast<unsigned long>(buffer[5]));
	else
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[5]) << 40 |
			static_cast<unsigned long>(buffer[4]) << 32 |
			static_cast<unsigned long>(buffer[3]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[1]) << 8 |
			static_cast<unsigned long>(buffer[0]));

	return a;
}
int64_t buff_6_ToInt64(int8_t* buffer, bool order)
{
	int64_t a;
	if (!order)
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[0]) << 40 |
			static_cast<unsigned long>(buffer[1]) << 32 |
			static_cast<unsigned long>(buffer[2]) << 24 |
			static_cast<unsigned long>(buffer[3]) << 16 |
			static_cast<unsigned long>(buffer[4]) << 8 |
			static_cast<unsigned long>(buffer[5]));
	else
		a = static_cast<long long int>(
			static_cast<unsigned long>(buffer[5]) << 40 |
			static_cast<unsigned long>(buffer[4]) << 32 |
			static_cast<unsigned long>(buffer[3]) << 24 |
			static_cast<unsigned long>(buffer[2]) << 16 |
			static_cast<unsigned long>(buffer[1]) << 8 |
			static_cast<unsigned long>(buffer[0]));

	return a;
}
//--------------------------------------------------------------------------------------

uint32_t buffToInt32(uint8_t* buffer, bool order)/**/
{
	uint32_t a;
	if (!order)
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[0]) << 24 |
			static_cast<unsigned int>(buffer[1]) << 16 |
			static_cast<unsigned int>(buffer[2]) << 8 |
			static_cast<unsigned int>(buffer[3]));
	else
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[3]) << 24 |
			static_cast<unsigned int>(buffer[2]) << 16 |
			static_cast<unsigned int>(buffer[1]) << 8 |
			static_cast<unsigned int>(buffer[0]));

	return a;
}
int32_t buffToInt32(int8_t* buffer, bool order)
{
	int32_t a;
	if (!order)
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[0]) << 24 |
			static_cast<unsigned int>(buffer[1]) << 16 |
			static_cast<unsigned int>(buffer[2]) << 8 |
			static_cast<unsigned int>(buffer[3]));
	else
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[3]) << 24 |
			static_cast<unsigned int>(buffer[2]) << 16 |
			static_cast<unsigned int>(buffer[1]) << 8 |
			static_cast<unsigned int>(buffer[0]));

	return a;
}
//------------------------------------------------------------------------------------

uint16_t buffToInt16(uint8_t* buffer, bool order)/**/
{
	uint16_t a;
	if (order)
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[0]) << 8 |
			static_cast<unsigned int>(buffer[1]));
	else
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[1]) << 8 |
			static_cast<unsigned int>(buffer[0]));

	return a;
}
int16_t buffToInt16(int8_t* buffer, bool order)
{
	int16_t a;
	if (!order)
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[0]) << 8 |
			static_cast<unsigned int>(buffer[1]));
	else
		a = static_cast<unsigned int>(
			static_cast<unsigned int>(buffer[1]) << 8 |
			static_cast<unsigned int>(buffer[0]));

	return a;
}
//--------------------------------------------------------------------------------------

string DigToStr(int8_t dig, bool format)
{
	try
	{
		char b[9] = { 0 };

		sprintf(b, "%x", dig);
		string s(b);
		if (format) {
			if (dig < 16 && dig > -1)
				s = "0x0" + s;
			else if (dig > 15)
				s = "0x" + s;
			else if (dig < 0)
				s = "0x" + s.substr(s.length() - 2, 2);
		}
		else {
			if (dig < 16 && dig > -1)
				s = "0" + s;
			else if (dig < 0)
				s = s.substr(s.length() - 2, 2);
		}
		return s;
	}
	catch (const std::exception&)
	{
	}
}

void intToBytes(long long int paramInt, unsigned char* buf, size_t size)
{
	for (int i = 0; i < size; i++)
		buf[i] = paramInt >> (i * 8) & 0xFF;
}
//---------------------------------------------------------------------------------------

void intToBytes_rev(long long int paramInt, unsigned char* buf, size_t size)
{
	for (int i = 0; i < size; i++)
		buf[size - i - 1] = paramInt >> (i * 8) & 0xFF;
}
//---------------------------------------------------------------------------------------

bool atob(string str)
{
	if (str == "Y" || str == "y" || str == "Yes" || str == "yes" || str == "1" || str == "t" || str == "T" || str == "True" || str == "true"
		|| str == "true" || str == "FALSE")
		return true;
	else
		return false;
}
//-----------------------------------------------------------------------------

string btoa(bool value)
{
	if (value)
		return "true";
	else
		return "false";
}
//-----------------------------------------------------------------------------

////-----------------------------------------------------------------------------
