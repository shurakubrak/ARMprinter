#include "Socket.h"
#include "Loger.h"

extern bool Terminated;;
extern Loger Log;

// ������� ������ � ����
unsigned age_pack = 0;



//////////////////////////////////////////////////////////////////////////////////
///////// SocketClient //////////////////////////////////////////////////////////

// ����� ������ ��� ������ �������
void* thread_ClientSock_read(void* arg)
{
	SocketClient* Sock = (SocketClient*)arg;

	while (!Sock->Connect() && Terminated == false)
		ssleep(3);
	while (Terminated == false) {
		if (!Sock->Recive()) {
			// ���������� ���� ������� ���������
			//T_TDOA.first_msg = true;
			while (!Sock->Connect())
				ssleep(3);
		}
		pthread_yield();
	}
	Sock->Close();
	cout << "Stop thread for socket client: " << Sock->server_addr << endl;
	return nullptr;
}
//------------------------------------------------------------------

bool SocketClient::Connect()
{
	try
	{
		if (ClientSock > -1) {
			close(ClientSock);
			status = false;
		}

		// �����
		ClientSock = socket(AF_INET, SOCK_STREAM, 0);
		if (ClientSock < 0)
		{
			Log.ToLog("Socket init error: " + server_addr + " - " + itoa(port));
			return false;
		}

		to_sin.sin_family = AF_INET;
		to_sin.sin_port = htons(port);
		int s = inet_pton(AF_INET, server_addr.c_str(), &to_sin.sin_addr);
		if (s <= 0) {
			if (s == 0)
				Log.ToLog("Socket addr not in presentation format");
			else
				Log.ToLog("Socket addr error in 'inet_pton'");
			return false;
		}


		//��������� ���������� � ��������
		if (connect(ClientSock, (struct sockaddr*) & to_sin, sizeof(to_sin)) != 0) {
			perror("socket clent connection error: ");
			Log.ToLog("CONNECTION ERR: " + itoa(ClientSock) + "/" + server_addr + " - " + itoa(port));
			return false;
		}
		Log.ToLog("Socket connect OK: " + itoa(ClientSock) + "/" + server_addr + " - " + itoa(port));
		status = true;
		sync = true;

		return true;
	}
	catch (...)
	{
		cout << "Connect to VS catch" << endl;
		return false;
	}
}
//----------------------------------------------------------

void SocketClient::StartExchange()
{
	try
	{
		int ret = pthread_create(&thrRead, NULL, thread_ClientSock_read, (void*)this);
		if (ret)
			Log.ToLog("ERROR nLES thread create");
		else
			pthread_detach(thrRead);
	}
	catch (const std::exception&)
	{
		Log.ToLog("Cath in 'void SocketClient::StartExchange()'");
		return;
	}
}
//----------------------------------------------------

void	SocketClient::Close()
{
	Terminated = true;
	usleep(100000);
	if (ClientSock > -1)
		close(ClientSock);
}
//------------------------------------------------------------

bool SocketClient::Status()
{
	try
	{
		int error = -1;
		socklen_t len = sizeof(error);
		getsockopt(ClientSock, SOL_SOCKET, SO_ACCEPTCONN, (char*)&error, &len);
		if (error != 0 || !status) {
			Log.ToLog("Socket: " + itoa(ClientSock) + "/" +server_addr + " port:" + itoa(port) +
				+ " status faul, error code: " + itoa(errno)
				+ ", connection will be destrow");
			return false;
		}
		return true;
	}
	catch (const std::exception&)
	{
		return false;
	}
}
//----------------------------------------------------------

bool SocketClient::Send(const char* Message, size_t size)
{
	try
	{
		if (Status()) {
			size_t err = send(ClientSock, Message, size, MSG_DONTROUTE);
			if (err < 0) {
				Log.ToLog("Socket " + itoa(ClientSock)
					+ " send faul, error code: " + itoa(errno)
					+ ", connection will be destrow");
				Close();
				return false;
			}
			return true;
		}
		return false;
	}
	catch (...)
	{
		Log.ToLog("Catch in 'bool SocketClient::Send(Byte* Message, size_t size)'");
		return false;
	}
}
//----------------------------------------------------------------------------


bool SocketClient::Recive()
{
	Byte szBuffer[LenTCPbuffer];
	
	try {
		if (ClientSock < 0) return false;
		int count = recv(ClientSock, szBuffer, LenTCPbuffer, 0);
		if (count < 0) {
			perror("socket read error: ");
			Log.ToLog("Socket " + server_addr
				+ " - " + itoa(port)
				+ ", read faul, error code: " + itoa(errno)
				+ ", connection will be destrow");
			return false;
		}
		else if (count == 0) {
			perror("socket read error: ");
			Log.ToLog("Socket " + server_addr
				+ " - " + itoa(port)
				+ ", read 0 bytes, connection will be destrow");
			return false;
		}
		else if(count < 1001)
			for (size_t i = 0; i < count; i++)
				Analys(szBuffer[i]);
		return true;
	}
	catch (...) {
		return false;
	}
}
//-------------------------------------------------------------------------

void SocketClient::AddMsg(vector<Byte>* msg)
{
	MsgInAccess(msg, WRITE);
}
bool SocketClient::GetMsg(vector<Byte>* msg)
{
	return MsgInAccess(msg, READ);
}
//-----------------------------------------------------------------------

bool SocketClient::MsgInAccess(vector<Byte>* msg, int access)
{
	try
	{
		unique_lock<mutex> locker(mtxIn);
		switch (access)
		{
		case WRITE:
			lstIn.push_back(*msg);
			return true;
		case READ:
			if (lstIn.size() > 0) {
				*msg = lstIn.front();
				lstIn.pop_front();
				return true;
			}
			break;
		default:
			break;
		}
		return false;
	}
	catch (const std::exception&)
	{
		return false;
	}
}


