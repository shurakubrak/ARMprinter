﻿#include "main.h"
#include <linux/lp.h>
#include <sys/ioctl.h>

#include <fcntl.h>
#include <linux/cdrom.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <algorithm>

extern Loger Log;



void PrintCtl()
{
	int printer = open("/dev/usb/lp0", O_RDONLY);
	int* arg;
	if (printer != ERROR) {
		int stat = ioctl(printer, LPGETSTATUS, arg);
		Log.ToLog("ioctl ERROR: " + to_string(errno));
		close(printer);
	}
	else
		Log.ToLog("open ERROR: " + to_string(errno)); 
	return;
}
//-------------------------------------------------------------------

size_t LengthStrNoSpace(string str)
{
	size_t size = 0;
	for (size_t i = 0; i < str.length(); i++)
		if (str[i] != ' '
			&& str[i] != '\n'
			&& str[i] != '\r')
			size++;
	return size;
}

//ENOENT
//LP_PBUSY

bool lstPrintAccess(Doc* doc, int acc)
{
	unique_lock<mutex> locker(mx_lstPrint);
	switch (acc)
	{
	case ADD:
		lstPrint.push_back(*doc);
		return true;
		break;
	case GET:
		if (lstPrint.size()) {
			lstPrint.front().CopyTo(doc);
			lstPrint.pop_front();
			return true;
		}
		break;
	}
	return false;
}
//------------------------------------------------------

string ReadAddr()
{
	string addr = "";
	char buf[20];
	try
	{
		ifstream f;
		f.open("/home/orangepi/settngs.txt");
		getline(f, addr);
		return addr;
	}
	catch (const std::exception&)
	{	}
}
//----------------------------------------------------

void Request_1()
{
	try
	{
		char buf[] = { BEGIN_PACK,'1',SEPARATOR_PACK,'1',END_PACK };
		buf[3] = (getUSB()) ? '1' : '2'; /*2 - нет принтера*/
		if (fl_PrintFail) 
			buf[3] = '3'; /*ошибка принтера*/
		sClient.Send(buf, sizeof(buf));

	}
	catch (const std::exception&)
	{	}
}
//---------------------------------------------------------

void Request_2()
{
	try
	{
		string pack;
		pack += BEGIN_PACK;
		pack += '2';
		pack += SEPARATOR_PACK;
		pack += to_string(CmdCurrent.load());
		pack += END_PACK;
		sClient.Send(pack.c_str(), pack.length());
	}
	catch (const std::exception&)
	{	}
}
//----------------------------------------------------------

bool Request_3(string OrderCur, string CmdCur, int line_num, int char_num, bool status)
{
	try
	{
		string pack;
		pack += BEGIN_PACK;
		pack += "3";
		pack += SEPARATOR_PACK;
		pack += OrderCur;
		pack += SEPARATOR_PACK;
		pack += CmdCur;
		pack += SEPARATOR_PACK;
		pack += itoa(line_num);
		pack += SEPARATOR_PACK;
		pack += itoa(char_num);
		pack += SEPARATOR_PACK;
		pack += (status)? "8": "10";
		pack += END_PACK;

		sClient.Send(pack.c_str(), pack.length());
		//Log.ToLog(" Send to server dok-pack: " + to_string(status));
	}
	catch (const std::exception&)
	{	}
}
//------------------------------------------------------------

void* thread_Timer(void* arg)
{
	while (!Terminated) {
		if(fl_LinePrint)
			if (!wait4(&fl_LinePrint, 2000)) {
				fl_PrintFail = true;
				Request_3(itoa(OrderCurrent), itoa(CmdCurrent), CountLinePrint, CountCharPrint, false);
				CountLinePrint = 0;
				CountCharPrint = 0;
				fl_LinePrint = false;
			}
		msleep(10);
	}
}
//-----------------------------------------------------------

void* thread_Printer(void* arg)
{
	Doc doc;
	size_t pos;
	string left_space = "";
	string space = "";
	space += '\n';
	string head = "";
	string bottom = "";
	bool err = false;

	try
	{ 
		while (!Terminated) {
			if (lstPrintAccess(&doc, GET)) {
				Log.ToLog("Doc start.");
				CountLinePrint = 0;
				CountCharPrint = 0;
				OrderCurrent = atoi(doc.order_id.c_str());
				CmdCurrent = atoi(doc.cmd_id.c_str());
				/*колонтитулы*/
				left_space = "";
				for (size_t i = 0; i < doc.MarginLeft; i++)
					left_space += " ";
				
				doc.lines.push_front(space);
				head = left_space + "---Копия N-----------Задание на пост передано " + doc.dt + '\n';
				head = convert(head.c_str(), "utf-8", "cp1251");
				doc.lines.push_front(head);
				
				bottom = left_space + "---Конец копии------------передано " + doc.dt + '\n';
				bottom = convert(bottom.c_str(), "utf-8", "cp1251");
				doc.lines.push_back(bottom);
				doc.lines.push_back(space); /*пустая строка ввеху копии*/
				
				doc.line_num += 4;
				
				for (size_t i = 0; i < doc.copies; i++) {
					pos = doc.lines.front().find('N');
					if (pos != string::npos)
						doc.lines.front().replace(pos+1, to_string(i + 1).length(), to_string(i + 1));
					
					/*печатаем*/
					for (auto it = doc.lines.begin(); it != doc.lines.end(); it++) {
						while (!getUSB())
							msleep(100);
						if (PrintString(*it)) {
							CountLinePrint++;
							CountCharPrint += LengthStrNoSpace(*it);
							msleep(10);
						}
						else
							err = true;
					}
				}
				/*отступ снизу*/
				for (size_t i = 0; i < doc.MarginCount; i++) {
					while (!getUSB())
							msleep(100);
					if (PrintString(space)) {
						CountLinePrint++;
						msleep(10);
					}
					else
						err = true;
				}

				if(doc.confirm)
					LEDon(true);
				if (err)
					Log.ToLog("Print error"); 
				else{
					Request_3(doc.order_id, doc.cmd_id, CountLinePrint, CountCharPrint, true);
					Log.ToLog("Doc printed, lines number:" + to_string(CountLinePrint) +
						"/" + to_string(doc.lines.size() * doc.copies) + 
						"  characters: " + to_string(CountCharPrint));
				}
				err = false;
				CountLinePrint = 0;
				CountCharPrint = 0;
				doc.Clear();
			}
			else
				msleep(50);
		}
	}
	catch (const std::exception&)
	{
		cout << "Error print" << endl;
	}
}
//----------------------------------------------------------

int main()
{
	Log.ToLog("START...", CF);
	DeviceOpen();
	PrintCtl();
	LEDon(true);
	sleep(1);
	LEDon(false);	
	string str = {7, 17, 27, 64, 27, 107, 48 };
	
	sClient.server_addr = ReadAddr();
	sClient.StartExchange();

	thread thrTimer = thread(thread_Timer, nullptr);
	thrTimer.detach();

	thread thrPrint = thread(thread_Printer, nullptr);
	thrPrint.detach();

	uint64_t tm = get_time_ms();
	Request_2();
	while (!Terminated)
	{
		if (KEYget() && ifClick) {
			LEDon(false);
			Request_2();
			ifClick = false;
		}

		/*контроль принтера*/
		if (fl_PrintFail) {
			if (!getUSB()) 
				fl_PrintFail = false;
		}
		
		/*маяк*/
		if (get_time_ms() - tm > BLINK_TIME) {
			Request_1();
			tm = get_time_ms();
		}
		msleep(50);
	}

	Terminated = true;
	sClient.Close();
	ssleep(1);
	Log.Terminated = true;
	ssleep(2);
	return 0;
}
//-------------------------------------------------------

/**********************************************/
/**** class IN_Conn **************************/
void Client::Analys(Byte bt)
{
	try
	{
		if (byte_count >= LENGH_PACK)
			begin = false;
		else {
			switch (bt)
			{
			case BEGIN_PACK:
				byte_count = 0;
				message.clear();
				message.push_back(bt);
				byte_count++;
				begin = true;
				break;
			case END_PACK:
				begin = false;
				message.push_back(bt);
				Parse();
				break;
			default:
				if (begin) {
					message.push_back(bt);
					byte_count++;
				}
				break;
			}
		}
	}
	catch (const std::exception&)
	{ 
		begin = false;
	}
}
//--------------------------------------------

void Client::Parse()
{
	try
	{
		string str = "";
		size_t pos = 0;
		
		
		switch (message[1])
		{
		case '1':
			Request_1();
			break;
		
		case '3':
			fl_Document_Begin = true;
			Document.Clear();
			/*order_id*/
			for (int i = 3; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					Document.order_id += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			/*cmd_id*/
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					Document.cmd_id += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			/*copies*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.copies = atoi(str.c_str());
			/*confirm*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.confirm = atob(str);
			/*lines number*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.line_num = atoi(str.c_str());
			/*MarginCount - отступ снизу*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.MarginCount = atoi(str.c_str());
			/*MarginLeft - отступ слевау*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.MarginLeft = atoi(str.c_str());
			/*MaxNumSimbol - кол. символов в строке*/
			str = "";
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK)
					str += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			Document.MaxNumSimbol = atoi(str.c_str());
			/*date-time*/
			for (int i = pos; i < message.size(); i++) {
				if (message[i] != SEPARATOR_PACK && message[i] != END_PACK)
					Document.dt += message[i];
				else {
					pos = i + 1;
					break;
				}
			}
			break;
		
		case '4':
			if (fl_Document_Begin) {
				for (int i = 3; i < message.size()-1; i++)
					str += message[i];
				Document.lines.push_back(str);
				if (Document.lines.size() >= Document.line_num) {
					lstPrintAccess(&Document, ADD);
					fl_Document_Begin = false;
					Document.Clear();
				}
			}
			break;
		}
	}
	catch (const std::exception&)
	{
	}
}
//--------------------------------------------------------------

void DeviceOpen()
{
	wiringPiSetup();
	pinMode(LED_MAIN, OUTPUT);
	pinMode(KEY_MAIN, INPUT);
}
//------------------------------------------------------------

void LEDon(bool set)
{
	digitalWrite(LED_MAIN, set);
}
//------------------------------------------------------------

bool KEYget()
{
	if (digitalRead(KEY_MAIN))
		ifClick = true;
	return !digitalRead(KEY_MAIN);
}
//---------------------------------------------------------

bool getUSB()
{
	bool LSU = false;
	FILE* fpipe;
	char c = 0;
	if (0 == (fpipe = (FILE*)popen(command, "r")))
	{
		perror("popen() failed.");
		return false;
	}
	while (fread(&c, sizeof c, 1, fpipe)) 
		LSU = true;
	pclose(fpipe);
	return LSU;	
}
//---------------------------------------------------------

bool PrintString(string line)
{
	try
	{
		fl_LinePrint = true;
		
		ofstream printer("/dev/usb/lp0");
		if (printer.is_open()) {
			printer << line;
			printer.close();
			msleep(100);
			fl_LinePrint = false;
			fl_PrintFail = false;
			return true;
		}
		else {
			return false;
		}
	}
	catch (const std::exception&)
	{
		return false;
	}
}
//--------------------------------------------------------

char* convert(const char* s, const char* from_cp, const char* to_cp)
{
	iconv_t ic = iconv_open(to_cp, from_cp);

	if (ic == (iconv_t)(-1)) {
		fprintf(stderr, "iconv: cannot convert from %s to %s\n", from_cp, to_cp);
		return "";
	}

	char* out_buf = (char*)calloc(strlen(s) + 1, 1);
	char* out = out_buf;
	char* in = (char*)malloc(strlen(s) + 1);
	strcpy(in, s);

	size_t in_ln = strlen(s);
	size_t out_ln = in_ln;
	size_t k = iconv(ic, &in, &in_ln, &out, &out_ln);
	if (k == (size_t)-1)
		fprintf(stderr, "iconv: %u of %d converted\n", k, strlen(s));
	iconv_close(ic);
	return out_buf;
}
//-------------------------------------------------






