#pragma once


#include "Header.h"
#include "Socket.h"
#include "Loger.h"
#include <wiringPi.h>

bool Terminated = false;
atomic<bool> fl_PrintFail(false);

char* command = "lsusb | grep 04b8:0046";

#define LED_MAIN	16
#define KEY_MAIN	4
#define TIMER_PER_LINE		0.5
#define SEPARATOR_PACK		0x01
#define BEGIN_PACK			0x02
#define END_PACK			0x03
#define LENGH_PACK			250
#define MIN_LENGH_PACK		5
#define BLINK_TIME			3000



typedef struct{
	char tpe;
	const char* data;
	char c;
}PackArr;

struct ComdArr {
	char command;
	string data;
	string str;
	ComdArr() {
		command = '0';
		data = "";
		str = "";
	}
	void CopyTo(ComdArr* pack) {
		pack->command = command;
		pack->data = data;
		pack->str = str;
	}
};

/**********************************************/
/**** class IN_Conn **************************/
class Client : public SocketClient
{
public:
	Client() {	};
	int step = 0;
	void	Analys(Byte bt);
	void	Parse();
};
//------------------------------------


/* ���������� */
Client sClient;
pthread_t thrPrint;

string currIDx = "";
bool ifClick = false;

struct Doc
{
	string order_id;
	string cmd_id;
	uint8_t copies;
	bool confirm;
	uint16_t line_num;
	uint8_t MarginCount;
	uint8_t MarginLeft;
	uint8_t MaxNumSimbol;
	string dt;
	list <string> lines;
	Doc() {
		order_id = "";
		cmd_id = "";
		copies = 0;
		confirm = false;
		line_num = 0;
		MarginCount = 0;
		MarginLeft = 0;
		MaxNumSimbol = 80;
		lines.clear();
		dt = "";
	}
	void CopyTo(Doc* doc) {
		doc->order_id = order_id;
		doc->cmd_id = cmd_id;
		doc->copies = copies;
		doc->confirm = confirm;
		doc->line_num = line_num;
		doc->MarginCount = MarginCount;
		doc->MarginLeft = MarginLeft;
		doc->MaxNumSimbol = MaxNumSimbol;
		doc->lines = lines;
		doc->dt = dt;
	}
	void Clear() {
		order_id = "";
		cmd_id = "";
		copies = 0;
		confirm = false;
		line_num = 0;
		MarginCount = 0;
		MarginLeft = 0;
		MaxNumSimbol = 80;
		lines.clear();
		dt = "";
	}
};
Doc Document;
bool fl_Document_Begin = false;
list <Doc> lstPrint;
mutex mx_lstPrint;
bool lstPrintAccess(Doc* str, int acc);

atomic<bool> fl_LinePrint(false);
atomic<int> CountLinePrint(0);
atomic<int> CountCharPrint(0);
atomic<int> OrderCurrent(ERROR);
atomic<int> CmdCurrent(ERROR);

void DeviceOpen();
void LEDon(bool set);
bool KEYget();
bool getUSB();
bool PrintString(string line);

char* convert(const char* s, const char* from_cp, const char* to_cp);

string ReadAddr();
void Request_1();
void Request_2();
bool Request_3(string OrderCur, string CmdCur, int line_num, int char_num, bool status =true);
void PrintCtl();
size_t LengthStrNoSpace(string str);



